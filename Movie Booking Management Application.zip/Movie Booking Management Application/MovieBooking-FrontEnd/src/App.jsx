import axios, { AxiosError } from 'axios';
import React, { useEffect, useState } from 'react'
import './App.css';

function App() {
    const [callstate, setCallstate] = useState("fail");
    const [moviesdata, setMoviesdata] = useState([])
    useEffect(() => {
        const fetchdata = async () => {
            const data = await axios.get('http://localhost:8080/booking/getAll')
            setMoviesdata(data.data)
        }
        fetchdata();
    }, [callstate]);

    const [movie, setmovie] = useState({
        "movie_id": 0,
        "movie_name": "",
        "movie_lang": "",
        "movie_duration": 0,
        "movie_rating": 0,
        "movie_availability": ""
    })

    const fetchdata = async () => {
        const data = await axios.get('http://localhost:8080/booking/getAll')
        setMoviesdata(movie.data)
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        setmovie({
            ...movie,
            [name]: value
        })
    }

    const createMovie = async (e) => {
        e.preventDefault();
        const data = await axios.post('http://localhost:8080/booking/addMovie', movie)
        console.log(data)
        setCallstate(data.data)
    }

    const deleteMovie = async (id) => {
        const data = await axios.delete(`http://localhost:8080/booking/remove/${movie.movie_id}`)
        setCallstate(data)
    }

    const updateMovie = async (e) => {
        const data = await axios.put(`http://localhost:8080/booking/update/${movie.movie_id}`, movie)
        setCallstate(data);
    }

    return (
        <div>
            <form>
                Id: <input type="number" name="movie_id" value={movie.movie_id} onChange={handleChange} />
                <br />
                Name: <input type="text" name="movie_name" value={movie.movie_name} onChange={handleChange} />
                <br />
                Language:
                 <select id="movie_lang" name="movie_lang"value={movie.movie_lang} onChange={handleChange}  >
                    <option value="english">English</option>
                    <option value="Tamil">Tamil</option>
                    <option value="spanish">Spanish</option>
                    <option value="french">French</option>
                </select>
                <br />
                Duration: <input type="number" name="movie_duration" value={movie.movie_duration} onChange={handleChange} />
                <br />
                Rating: <input type="number" name="movie_rating" value={movie.movie_rating} onChange={handleChange} />
                <br />
                Availability: <input type="datetime-local" name="movie_availability" value={movie.movie_availability} onChange={handleChange} />
                <br />
                <button onClick={createMovie}>Add Movie</button>
                <button onClick={updateMovie}>update user</button> 
            </form>
            <br />
            <h4>Delete Movie</h4>
            <form>
            Id: <input type="number" name="movie_id" value={movie.movie_id} onChange={handleChange} />
                <br />
                <button onClick={deleteMovie}>Delete</button>
            </form>
            <br />
            {moviesdata.map(std => <div className='container'>
                <table border={"1px"}><td>{std.movie_name}</td><td>{std.movie_id}</td><td>{std.movie_lang}</td><td>{std.movie_duration}</td><td>{std.movie_rating}</td><td>{std.movie_availability}</td></table>
            </div>)}
        </div>
    )
}
export default App